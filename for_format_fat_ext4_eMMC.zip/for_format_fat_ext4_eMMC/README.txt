cp mkfs/ext4 vao sbin
chmod +x no luon
chmod +x /sbin/mkfs.ext4